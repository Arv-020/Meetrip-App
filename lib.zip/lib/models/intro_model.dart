class IntroModel {
  IntroModel({
    required this.image4,
    required this.image1,
    required this.image2,
    required this.image3,
    required this.title,
    required this.subTitle,
    required this.buttonTxt,
  });
  final String image1;
  final String image2;
  final String image3;
  final String image4;
  final String title;
  final String subTitle;
  final String buttonTxt;
}
